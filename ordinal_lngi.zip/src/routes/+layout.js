// src/routes/+layout.js
export const ssr = false; // 关闭 SSR
export const prerender = true; // 强制预渲染