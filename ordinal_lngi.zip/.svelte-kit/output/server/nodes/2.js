

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.BaH38BuH.js","_app/immutable/chunks/gK7Wglfq.js","_app/immutable/chunks/DUspetes.js","_app/immutable/chunks/BEdG2tZZ.js","_app/immutable/chunks/DRsSU5qQ.js"];
export const stylesheets = [];
export const fonts = [];
