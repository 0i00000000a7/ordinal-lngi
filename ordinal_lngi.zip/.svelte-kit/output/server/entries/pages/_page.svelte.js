import "clsx";
import { d as current_component, c as pop, p as push } from "../../chunks/index.js";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
function onDestroy(fn) {
  var context = (
    /** @type {Component} */
    current_component
  );
  (context.d ??= []).push(fn);
}
function _page($$payload, $$props) {
  push();
  let t = 0;
  onDestroy(() => {
  });
  function Infinitize(n) {
    return 1 / (1 - n) - 1;
  }
  function ordinal(x, top = true) {
    {
      return String(Math.floor(Infinitize(x / 3e3)));
    }
  }
  $$payload.out += `${html(ordinal(t))}<br>`;
  pop();
}
export {
  _page as default
};
